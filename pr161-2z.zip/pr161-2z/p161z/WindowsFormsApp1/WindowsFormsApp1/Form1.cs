﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int i = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Слон и моська. Слон повстречал моську и СЛОН…";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if (WhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Введите текст", "Ошибка");
            }    
            else if (WhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Введите слово, которое хотите найти", "Ошибка");
            }
            else
            {
                i = 0;
                string[] words = textBox1.Text.ToLower().Split(' ');

                var selectedText = from t in words
                                   where t.Contains(textBox2.Text.ToLower())
                                   orderby t
                                   select t;
                foreach (string s in selectedText)
                    i++;
            label4.Text = $"{i} вхождения слова {textBox2.Text}";

            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        public bool WhiteSpace(string text)
        {
            if (string.IsNullOrEmpty(text))
                return true;

            return false;
        }
    }
}
