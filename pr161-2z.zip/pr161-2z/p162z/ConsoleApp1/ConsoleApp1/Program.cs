﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите массив строк через запятую: ");
            string input = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(input))
            {
                Console.Clear();
                Console.WriteLine("error");
                Console.ReadKey();
                return;
            }
            string[] array = input.Split(',');

            var digits = array.SelectMany(str => str.Where(char.IsDigit)).ToList();
            Console.WriteLine($"Цифры: {string.Join(", ", digits)}");
            Console.WriteLine($"Количество цифр: {digits.Count}");

            var doslash = array.TakeWhile(str => !str.Contains("/")).ToList();
            Console.WriteLine("Элементы до символа \"/\":");
            doslash.ForEach(Console.WriteLine);

            var posleslash = array.SkipWhile(str => !str.Contains("/")).Skip(1)
                                          .Select(str => new string(str.Select(ch => char.IsLetter(ch)
                                              ? (char.IsUpper(ch) ? char.ToLower(ch) : char.ToUpper(ch))
                                              : ch).ToArray()))
                                          .ToList();
            Console.WriteLine("Элементы после символа \"/\" с измененным регистром:");
            posleslash.ForEach(Console.WriteLine);

            File.WriteAllLines("output.txt", posleslash);
            Console.Read();
        }
    }
}
